# main/main_module.py
from entity.courier import Courier
from dao.courier_service_db import CourierServiceDB
from util.db_conn_util import DBConnection
from dao.courier_user_service_impl import CourierUserServiceImpl
from dao.courier_admin_service_impl import CourierAdminServiceImpl
from util.password_util import generate_password
import re
from fuzzywuzzy import fuzz # type: ignore
from util.address_util import find_similar_addresses
from entity.user import User

def main():
    # Initialize DB Connection and Services
    db_service = CourierServiceDB()
    conn = db_service.connect()
    if conn:
        cursor = db_service.conn.cursor()
        try:
            cursor.execute("SELECT * FROM Users")  # Corrected table name
            rows = cursor.fetchall()
            if rows:
                print("\n--- Users in DB ---")
                for row in rows:
                    print(row)
        except Exception as e:
            print(f"Error executing query: {e}")
        finally:
            db_service.close()
    else:
        print("Failed to connect to database.")
        return

    user_service = CourierUserServiceImpl(db_service)
    admin_service = CourierAdminServiceImpl(db_service)

    while True:
        print("\nCourier Management System")
        print("1. List All Customers")
        print("2. Track Courier")
        print("3. Create User")
        print("4. Validate Customer Info")
        print("5. Generate Password")
        print("6. Find Similar Addresses")
        print("7. List All Couriers")
        print("8. Exit")

        choice = input("Enter choice: ")

        if choice == '1':
            customers = db_service.list_all_customers()
            if customers:
                for c in customers:
                    print(c)
            else:
                print("No customers found.")

        elif choice == '2':
            tracking_number = input("Enter tracking number: ")
            courier = db_service.get_courier_by_tracking_number(tracking_number)
            if courier:
                print("Courier Found:", courier)
            else:
                print("No courier found for that tracking number.")

        elif choice == '3':
            userid = int(input("Enter user ID: "))  # Prompt for user ID
            name = input("Enter name: ")
            email = input("Enter email: ")
            password = input("Enter password: ")
            contactnumber = input("Enter contact number: ")
            address = input("Enter address: ")

            new_user = User(userid=userid, name=name, email=email, password=password, contactnumber=contactnumber, address=address)
            success = user_service.create_user(new_user)
            if success:
                print("User created successfully!")
            else:
                print("Failed to create user.")

        elif choice == '4':
            info = input("Enter Customer info ")
            detail = input("Enter what you are validating (name, address, phone number): ")
            is_valid = user_service.validate_customer_info(info, detail)  # Use the service method
            print(f"Validation result: {is_valid}")

        elif choice == '5':
            print("Secure password generated:", generate_password())

        elif choice == '6':
            address = input("Enter address to compare ")
            addresses = ["2220A university ave", "2220 university avenue"]
            print(find_similar_addresses(address, addresses))

        elif choice == '7':
            couriers = db_service.list_all_couriers()
            if couriers:
                for courier in couriers:
                    print(courier)
            else:
                print("No couriers found.")

        elif choice == '8':
            break
        else:
            print("Invalid choice!")

if __name__ == "__main__":
    main()
