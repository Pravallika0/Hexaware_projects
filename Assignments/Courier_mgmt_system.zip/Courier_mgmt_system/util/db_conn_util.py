# util/db_conn_util.py
import pyodbc  # type: ignore
from util.db_property_util import DBPropertyUtil

class DBConnection:
    def __init__(self):
        self.connection_string = DBPropertyUtil.get_connection_string()

    def connect(self):
        try:
            # Try to establish a connection using the connection string
            conn = pyodbc.connect(self.connection_string)
            return conn
        except pyodbc.Error as e:
            print(f"Error connecting to database: {str(e)}")
            return None

# Test block
if __name__ == "__main__":
    db_connection = DBConnection()
    conn = db_connection.connect()
    
    # Check the connection
    if conn:
        print("Connected to the database successfully.")
        conn.close()  # Always close the connection when done
    else:
        print("Failed to connect to the database.")
