from fuzzywuzzy import fuzz # type: ignore
def find_similar_addresses(address, addresses):
    similar = []
    for addr in addresses:
        if fuzz.ratio(address, addr) > 80:
            similar.append(addr)
    return similar