import pyodbc # type: ignore
class DBPropertyUtil:
    @staticmethod
    def get_connection_string():
        server_name = "DESKTOP-VISNEDG\\SQLEXPRESS"  # SQL Server instance
        database_name = "courier_mgmt"

        conn_str = (
            f"Driver={{SQL Server}};"
            f"Server={server_name};"
            f"Database={database_name};"
            f"Trusted_Connection=yes;"
        )

        return conn_str

class DBConnection:
    def __init__(self):
        # Fetch the connection string from DBPropertyUtil
        self.connection_string = DBPropertyUtil.get_connection_string()

    def connect(self):
        try:
            # Try connecting to the database using pyodbc
            conn = pyodbc.connect(self.connection_string)
            return conn
        except pyodbc.Error as e:
            print(f"Error connecting to database: {str(e)}")
            return None

# Optional test block
if __name__ == "__main__":
    db_connection = DBConnection()
    conn = db_connection.connect()
    if conn:
        print("Connected to the database successfully.")
        conn.close()