# dao/courier_service_db.py
from math import e
import pyodbc  # type: ignore
from util.db_conn_util import DBConnection

class CourierServiceDB:
    def __init__(self):
        self.db_conn = DBConnection()
        self.conn = None
        self.cursor = None

    def connect(self):
        try:
            self.conn = self.db_conn.connect()
            if self.conn:
                self.cursor = self.conn.cursor()
                return True
            else:
                return False
        except pyodbc.Error as ex:
            print(f"Database connection error: {str(ex)}")
            return False

    def close(self):
        if self.cursor:
            self.cursor.close()
        if self.conn:
            self.conn.close()

    def list_all_customers(self):
        try:
            if not self.connect():
                return None
            self.cursor.execute("SELECT * FROM Users")
            return self.cursor.fetchall()
        except pyodbc.Error as ex:
            print(f"Database error: {str(e)}")
            return None
        finally:
            self.close()

    def get_courier_by_tracking_number(self, tracking_number):
        try:
            if not self.connect():
                return None
            self.cursor.execute("SELECT * FROM Courier WHERE TrackingNumber=?", (tracking_number,))
            return self.cursor.fetchone()
        except pyodbc.Error as ex:
            print(f"Database error: {str(e)}")
            return None
        finally:
            self.close()

    def insert_courier(self, courier):
        try:
            if not self.connect():
                return False

            sql = """
                INSERT INTO Courier(CourierID, SenderName, SenderAddress, ReceiverName, ReceiverAddress,
                Weight, Status, TrackingNumber, DeliveryDate)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            values = (
                courier.courier_id, courier.sender_name, courier.sender_address, courier.receiver_name,
                courier.receiver_address, courier.weight, courier.status, courier.tracking_number,
                courier.delivery_date
            )
            self.cursor.execute(sql, values)
            self.conn.commit()
            return True
        except pyodbc.Error as ex:
            print(f"Database error: {str(e)}")
            if self.conn:
                self.conn.rollback()  # Rollback in case of error
            return False
        finally:
            self.close()
            
    def list_all_couriers(self):
        try:
            if not self.connect():
                return None
            self.cursor.execute("SELECT * FROM Courier")
            return self.cursor.fetchall()
        except pyodbc.Error as ex:
            print(f"Database error: {str(e)}")
            return None
        finally:
            self.close()

    def insert_user(self, user):
        try:
            if not self.connect():
                return False

            sql = """
                INSERT INTO Users(userid, name, email, password, contactnumber, address)
                VALUES (?, ?, ?, ?, ?, ?)
            """
            values = (
                user.userid,
                user.name,
                user.email,
                user.password,
                user.contactnumber,
                user.address
            )
            self.cursor.execute(sql, values)
            self.conn.commit()
            return True
        except pyodbc.Error as e:
            print(f"Database error: {str(e)}")
            if self.conn:
                self.conn.rollback()
            return False
        finally:
            self.close()
