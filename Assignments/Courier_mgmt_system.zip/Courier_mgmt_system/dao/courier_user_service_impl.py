# dao/courier_user_service_impl.py
import re
import time
from dao.i_courier_user_service import ICourierUserService
from exception.tracking_number_not_found_exception import TrackingNumberNotFoundException
class CourierUserServiceImpl(ICourierUserService):
    def __init__(self, db_service):
        self.db_service = db_service

    def create_user(self, user):
        # You can add validation or password hashing here before inserting
        success = self.db_service.insert_user(user)
        return success

    def place_order(self, courier_obj):
        """Place a new courier order."""
        try:
            tracking_number = self.db_service.insert_courier(courier_obj)
            return tracking_number
        except Exception as e:
            print(f"Error placing order: {e}")
            return None

    def get_order_status(self, tracking_number):
        """Get the status of a courier order."""
        courier = self.db_service.get_courier_by_tracking_number(tracking_number)
        if not courier:
            raise TrackingNumberNotFoundException(f"Tracking number {tracking_number} not found")
        return courier.status

    def cancel_order(self, tracking_number):
        """Cancel a courier order."""
        try:
            courier = self.db_service.get_courier_by_tracking_number(tracking_number)
            if not courier:
                raise TrackingNumberNotFoundException(f"Tracking number {tracking_number} not found")

            # Implementation for canceling an order (e.g., updating status)
            return True
        except TrackingNumberNotFoundException as e:
            print(e)
            return False
        except Exception as e:
            print(f"Error canceling order: {e}")
            return False

    def get_assigned_order(self, courier_staff_id):
        """Get a list of orders assigned to a specific courier staff member."""
        # Implementation to retrieve assigned orders from the database
        pass

    def check_delivery_status(self, status):
        if status == "Delivered":
            return "Order has been delivered."
        elif status == "Processing":
            return "Order is still being processed."
        elif status == "Cancelled":
            return "Order has been cancelled."
        else:
            return "Order status is unknown."

    def categorize_parcel(self, weight):
        if weight < 1.0:
            return "Light"
        elif 1.0 <= weight <= 5.0:
            return "Medium"
        else:
            return "Heavy"

    def authenticate_user(self, username, password, users):
        for user in users:
            if user.username == username and user.password == password:
                return user
        return None

    def assign_courier(self, shipment, couriers):
        available_couriers = [c for c in couriers if c.load_capacity > shipment.weight]
        if available_couriers:
            return min(available_couriers, key=lambda c: c.proximity_to_shipment)
        return None

    def find_nearest_courier(self, new_order, couriers):
        available_couriers = [c for c in couriers if c.is_available]
        if available_couriers:
            return min(available_couriers, key=lambda c: c.distance_to(new_order.location))
        return None

    def display_customer_orders(self, customer_id, orders):
        customer_orders = [order for order in orders if order.customer_id == customer_id]
        for order in customer_orders:
            print(f"Order ID: {order.order_id}, Status: {order.status}")

    def track_courier_location(self, courier):
        while courier.location != courier.destination:
            print(f"Courier is currently at: {courier.location}")
            # courier.move_towards_destination() # Assuming this exists
            time.sleep(1)  # Simulate real-time tracking
        print("Courier has reached its destination!")

    def track_parcel(self, tracking_number, tracking_data):
        for record in tracking_data:
            if record[0] == tracking_number:
                return record[1]
        return "Tracking number not found."

    def validate_customer_info(self, data, detail):
        if detail == "name":
            return data.isalpha() and data.istitle()
        elif detail == "address":
            return all(char.isalnum() or char.isspace() for char in data)
        elif detail == "phone number":
            return re.match(r'^\d{3}-\d{3}-\d{4}$', data)
        return False

    def format_address(self, street, city, state, zip_code):
        formatted_street = street.title()
        formatted_city = city.title()
        formatted_zip = zip_code.zfill(5)
        return f"{formatted_street}, {formatted_city}, {state} {formatted_zip}"

    def generate_order_confirmation_email(self, customer_name, order_number, delivery_address, expected_delivery_date):
        subject = "Order Confirmation"
        body = f"Dear {customer_name},\nYour order {order_number} will be delivered to {delivery_address} by {expected_delivery_date}."
        return f"Subject: {subject}\n\n{body}"

    def calculate_shipping_costs(self, distance, weight):
        cost = distance * 0.1 + weight * 0.5
        return cost
