# dao/courier_admin_service_impl.py

from dao.courier_user_service_impl import CourierUserServiceImpl
from dao.i_courier_admin_service import ICourierAdminService
from exception.invalid_employee_id_exception import InvalidEmployeeIdException

class CourierAdminServiceImpl(CourierUserServiceImpl, ICourierAdminService):
    def __init__(self, db_service):
        super().__init__(db_service)

    def add_courier_staff(self, employee):
        """Add a new courier staff member to the system."""
        try:
            # Implementation to add employee to database using db_service
            employee_id = self.db_service.insert_employee(employee)
            return employee_id
        except Exception as e:
            print(f"Error adding employee: {e}")
            return None

    def update_employee_role(self, employee_id, new_role):
      """Update the role of an existing employee."""
      try:
          employee = self.db_service.get_employee_by_id(employee_id)
          if not employee:
              raise InvalidEmployeeIdException(f"Employee with ID {employee_id} not found.")

          # Implementation to update the employee's role in the database
          self.db_service.update_employee_role(employee_id, new_role)
          return True  # Indicate success
      except InvalidEmployeeIdException as e:
          print(e)
          return False
      except Exception as e:
          print(f"Error updating employee role: {e}")
          return False
