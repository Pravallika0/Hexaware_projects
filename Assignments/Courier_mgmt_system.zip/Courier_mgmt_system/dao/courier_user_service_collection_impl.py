from dao import i_courier_user_service


class CourierUserServiceCollectionImpl(i_courier_user_service):
    def __init__(self, company_obj):
        self.company_obj = company_obj