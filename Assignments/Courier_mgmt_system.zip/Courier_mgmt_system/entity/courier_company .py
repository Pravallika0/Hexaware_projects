# entity/courier_company.py
class CourierCompanyCollection:
    def __init__(self,company_name):
        self.company_name = company_name
        self.courier_details = []  # List of Courier objects
        self.employee_details = []  # List of Employee objects
        self.location_details = []  # List of Location objects

    def __str__(self):
        return f"CourierCompany({self.company_name})"
