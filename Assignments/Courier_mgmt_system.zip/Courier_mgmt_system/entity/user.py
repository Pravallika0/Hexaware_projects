# entity/user.py
class User:
    def __init__(self, userid, name, email, password, contactnumber, address):
        self.userid = userid
        self.name = name
        self.email = email
        self.password = password
        self.contactnumber = contactnumber
        self.address = address

    def __str__(self):
        return f"User ID: {self.userid}, Name: {self.name}, Email: {self.email}"

