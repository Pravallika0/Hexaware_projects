# util/db_conn_util.py

import pyodbc # type: ignore

def get_connection():
    conn_str = (
        "Driver={ODBC Driver 17 for SQL Server};"
        "Server=DESKTOP-VISNEDG\\SQLEXPRESS;"  # Modify if needed
        "Database=SISDB2;"
        "Trusted_Connection=yes;"
    )
    return pyodbc.connect(conn_str)
