from entity.student import Student
from entity.course import Course
from entity.teacher import Teacher
from entity.enrollment import Enrollment
from entity.payment import Payment

from dao.student_service_impl import StudentServiceImpl
from dao.course_service_impl import CourseServiceImpl
from dao.teacher_service_impl import TeacherServiceImpl
from dao.enrollment_service_impl import EnrollmentServiceImpl
from dao.payment_service_impl import PaymentServiceImpl

def main():
    student_service = StudentServiceImpl()
    course_service = CourseServiceImpl()
    teacher_service = TeacherServiceImpl()
    enrollment_service = EnrollmentServiceImpl()
    payment_service = PaymentServiceImpl()

    while True:
        print("\n--- SIS Main Menu ---")
        print("1. Add Student")
        print("2. View Students")
        print("3. Add Course")
        print("4. Add Teacher")
        print("5. Enroll Student")
        print("6. Add Payment")
        print("0. Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            sid = int(input("Student ID: "))
            fname = input("First Name: ")
            lname = input("Last Name: ")
            dob = input("DOB (YYYY-MM-DD): ")
            email = input("Email: ")
            phone = int(input("Phone Number: "))
            student = Student(sid, fname, lname, dob, email, phone)
            student_service.add_student(student)

        elif choice == "2":
            student_service.get_students()

        elif choice == "3":
            cid = int(input("Course ID: "))
            cname = input("Course Name: ")
            credits = input("Credits: ")
            tid = int(input("Teacher ID: "))
            course = Course(cid, cname, credits, tid)
            course_service.add_course(course)

        elif choice == "4":
            tid = int(input("Teacher ID: "))
            fname = input("First Name: ")
            lname = input("Last Name: ")
            email = input("Email: ")
            teacher = Teacher(tid, fname, lname, email)
            teacher_service.add_teacher(teacher)

        elif choice == "5":
            eid = int(input("Enrollment ID: "))
            sid = int(input("Student ID: "))
            cid = int(input("Course ID: "))
            edate = input("Enrollment Date (YYYY-MM-DD): ")
            enrollment = Enrollment(eid, sid, cid, edate)
            enrollment_service.add_enrollment(enrollment)

        elif choice == "6":
            pid = int(input("Payment ID: "))
            sid = int(input("Student ID: "))
            amt = int(input("Amount: "))
            pdate = input("Payment Date (YYYY-MM-DD): ")
            payment = Payment(pid, sid, amt, pdate)
            payment_service.add_payment(payment)

        elif choice == "0":
            print("Goodbye!")
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()
