from util.db_conn_util import get_connection

class EnrollmentServiceImpl:
    def add_enrollment(self, enrollment):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date)
            VALUES (?, ?, ?, ?)""",
            enrollment.enrollment_id, enrollment.student_id, enrollment.course_id, enrollment.enrollment_date)
        conn.commit()
        conn.close()
