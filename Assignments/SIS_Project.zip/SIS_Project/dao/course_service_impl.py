from util.db_conn_util import get_connection

class CourseServiceImpl:
    def add_course(self, course):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO Courses (course_id, course_name, credits, teacher_id)
            VALUES (?, ?, ?, ?)""",
            course.course_id, course.course_name, course.credits, course.teacher_id)
        conn.commit()
        conn.close()

    def get_courses(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Courses")
        for row in cursor.fetchall():
            print(row)
        conn.close()
