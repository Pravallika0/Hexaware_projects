from util.db_conn_util import get_connection

class TeacherServiceImpl:
    def add_teacher(self, teacher):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO Teachers (teacher_id, first_name, last_name, email)
            VALUES (?, ?, ?, ?)""",
            teacher.teacher_id, teacher.first_name, teacher.last_name, teacher.email)
        conn.commit()
        conn.close()

    def get_teachers(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Teachers")
        for row in cursor.fetchall():
            print(row)
        conn.close()
