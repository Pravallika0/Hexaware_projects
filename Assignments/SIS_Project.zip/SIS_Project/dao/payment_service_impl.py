from util.db_conn_util import get_connection

class PaymentServiceImpl:
    def add_payment(self, payment):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO Payments (payment_id, student_id, amount, payment_date)
            VALUES (?, ?, ?, ?)""",
            payment.payment_id, payment.student_id, payment.amount, payment.payment_date)
        conn.commit()
        conn.close()
