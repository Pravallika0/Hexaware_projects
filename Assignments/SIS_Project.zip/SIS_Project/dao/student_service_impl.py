from util.db_conn_util import get_connection

class StudentServiceImpl:
    def add_student(self, student):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO Students (student_id, first_name, last_name, date_of_birth, email, phone_number)
            VALUES (?, ?, ?, ?, ?, ?)""",
            student.student_id, student.first_name, student.last_name,
            student.date_of_birth, student.email, student.phone_number)
        conn.commit()
        conn.close()

    def get_students(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Students")
        for row in cursor.fetchall():
            print(row)
        conn.close()
