from entity.customer import Customer


class Account:
    def __init__(self, acc_number, acc_type, balance, customer: 'Customer'):
        self.acc_number = acc_number
        self.acc_type = acc_type
        self.balance = balance
        self.customer = customer

    def deposit(self, amount):
        self.balance += amount
        print(f"✅ Deposited {amount}. New Balance: {self.balance}")

    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
            print(f"✅ Withdrew {amount}. Remaining Balance: {self.balance}")
        else:
            print("❌ Insufficient balance.")

    def calculate_interest(self):
        if self.acc_type == 'savings':
            interest = self.balance * 0.045
            print(f"Interest: {interest}")
            return interest
        else:
            print("No interest on current accounts.")
            return 0

    def display_info(self):
        print(f"Account Number: {self.acc_number}")
        print(f"Type: {self.acc_type}, Balance: {self.balance}")
        self.customer.display_info()
