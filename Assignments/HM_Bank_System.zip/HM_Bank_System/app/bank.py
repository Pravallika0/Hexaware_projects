from entity.customer import Customer
from entity.account import Account

class Bank:
    def __init__(self, branch_name):
        self.branch_name = branch_name
        self.accounts = []
        self.last_acc_number = 1000

    def create_account(self, first_name, last_name, email, phone, address, acc_type, initial_balance):
        self.last_acc_number += 1
        customer = Customer(self.last_acc_number, first_name, last_name, email, phone, address)
        account = Account(self.last_acc_number, acc_type, initial_balance, customer)
        self.accounts.append(account)
        print(f"🎉 Account created successfully with Account Number: {self.last_acc_number}")

    def get_account_by_number(self, acc_number):
        for acc in self.accounts:
            if acc.acc_number == acc_number:
                return acc
        return None
