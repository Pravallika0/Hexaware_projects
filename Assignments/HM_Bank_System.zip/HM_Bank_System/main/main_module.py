from app.bank import Bank

def main():
    bank = Bank("Hexaware Main Branch")

    while True:
        print("\n--- HMBank Menu ---")
        print("1. Create Account")
        print("2. Deposit")
        print("3. Withdraw")
        print("4. Display Account Info")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            fname = input("First Name: ")
            lname = input("Last Name: ")
            email = input("Email: ")
            phone = input("Phone: ")
            address = input("Address: ")
            acc_type = input("Account Type (savings/current): ").lower()
            initial = float(input("Initial Balance: "))
            bank.create_account(fname, lname, email, phone, address, acc_type, initial)

        elif choice == "2":
            acc_no = int(input("Enter Account Number: "))
            amt = float(input("Amount to Deposit: "))
            acc = bank.get_account_by_number(acc_no)
            if acc:
                acc.deposit(amt)
            else:
                print("❌ Account not found.")

        elif choice == "3":
            acc_no = int(input("Enter Account Number: "))
            amt = float(input("Amount to Withdraw: "))
            acc = bank.get_account_by_number(acc_no)
            if acc:
                acc.withdraw(amt)
            else:
                print("❌ Account not found.")

        elif choice == "4":
            acc_no = int(input("Enter Account Number: "))
            acc = bank.get_account_by_number(acc_no)
            if acc:
                acc.display_info()
            else:
                print("❌ Account not found.")

        elif choice == "5":
            print("Thanks for using HMBank!")
            break

        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
